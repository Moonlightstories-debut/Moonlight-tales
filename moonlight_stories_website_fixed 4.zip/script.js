
console.log('Welcome to Moonlight Stories!');
